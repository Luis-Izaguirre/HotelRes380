

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.ArrayList;

public class StringInputGUI extends JFrame {

    //Input fields for customer
    private JTextField customerName;//sets up the input for the name
    private JTextField customerEmail;//sets up the input for the email
    private JTextField guestCount;//sets up the input for the guest count
    private JFormattedTextField checkInDate;// sets up the formated input for the check in date
    private JFormattedTextField checkOutDate;// sets up the formated input for the check out date

    private JButton submitButton;

    //Getter varaibles for injections
    private String name;//initializes strings to be used to set the input data too for processing
    private String email;
    private String guestCont;
    private String checkIn;
    private String checkOut;
    ArrayList<String> inputArray = new ArrayList<>();// this is the array that will be returned 

    public ArrayList<String> displayGUIAndWaitForSubmit() {
        setTitle("Reservation");//title of the gui
        setSize(700, 700);//size of the gui
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//end if the window is closed
        setLayout(new GridLayout(7, 2));//layout of the gui
        setLocationRelativeTo(null);//sets window to open in the middle of the screen

        customerName = new JTextField();//creates a new input box
        customerEmail = new JTextField();//creates a new input box
        guestCount = new JTextField();//creates a new input box
        checkInDate = createFormattedTextField("##/##/####");//creates a new formated input box
        checkOutDate = createFormattedTextField("##/##/####");//creates a new formated input box

        submitButton = new JButton("Submit");//creates new submit button


        submitButton.addActionListener(new ActionListener() {//checks to see if submit has been clicked, if yes then it preforms the following operations
            @Override
            public void actionPerformed(ActionEvent e) {// submit button clicked
                name = customerName.getText();//sets the variables equal to the inputs
                  email = customerEmail.getText();
                guestCont = guestCount.getText();
                checkIn = checkInDate.getText();
                checkOut = checkOutDate.getText();

            if (!isValidDate(checkIn) || !isValidDate(checkOut)) {//checks to see if the date inputs are in the proper format
                    JOptionPane.showMessageDialog(null, "Enter the dates in MM/DD/YYYY format.", "Invalid Date Format", JOptionPane.ERROR_MESSAGE);// pop up windo if the dates are invalid
                    clearFields();// clears the date feilds
                } else {
                    inputArray.add(name);//ads the values to the input array
                    inputArray.add(email);
                    inputArray.add(guestCont);
                    inputArray.add(checkIn);
                    inputArray.add(checkOut);
                    dispose(); // Close the window
                }
            }
        });

        add(new JLabel("Name:"));//adds the labels beside the input text boxes to the gui
        add(customerName);//adds the input text boxes to the gui
        add(new JLabel("Email:"));
        add(customerEmail);
        add(new JLabel("Guest Count:"));
        add(guestCount);
        add(new JLabel("Check In Date (MM/DD/YYYY):"));
        add(checkInDate);
        add(new JLabel("Check Out Date (MM/DD/YYYY):"));
        add(checkOutDate);
        add(submitButton);//adds the submit button to the gui

        setVisible(true);

        
        while (inputArray.isEmpty()) {//checks to see if the input array has any data in it
            try {
                Thread.sleep(100);// it waits if there is nothing in the array
            } catch (InterruptedException ex) {
                ex.printStackTrace();//error 
            }
        }

        return inputArray;// returns the input array
    }
    
    public JFormattedTextField createFormattedTextField(String format) {//creates a format for the date input boxes
        try {
            MaskFormatter maskFormatter = new MaskFormatter(format);
            maskFormatter.setPlaceholderCharacter('_');
            return new JFormattedTextField(maskFormatter);
        } catch (ParseException e) {//error
            e.printStackTrace();
            return new JFormattedTextField();
        }
    }

    public boolean isValidDate(String input) {//checks if the input dates for check in and check out are valid
        String[] parts = input.split("/");//creates an array based on the string input spliting it into 3 elements using the / to devide them up
        if (parts.length != 3) {//checks to see if it is long enough
            return false;
        }
        int month = Integer.parseInt(parts[0]);//sets the month to the first element of the array
        int day = Integer.parseInt(parts[1]);//sets the day to the seccond element
        int year = Integer.parseInt(parts[2]);//sets the year to the third element
        return (month >= 1 && month <= 12) && (day >= 1 && day <= 31) && (year >= 1000 && year <= 9999);//checks to see that each input is valid and there is no date line 13/32/0999
    }

    public void clearFields() {// clears the check in and check out date feilds 
        checkInDate.setValue(null);
        checkOutDate.setValue(null);
    
}
}
