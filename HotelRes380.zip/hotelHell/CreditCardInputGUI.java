
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class CreditCardInputGUI extends JFrame {
    private JTextField cardNumberField;
    private JTextField expirationField;
    private JTextField securityCodeField;
    private JTextField zipCodeField;
    private ArrayList<String> inArry;

    public void CreditCardInput(ArrayList<String> inArry) {//takes in an array with all the reservation information
        this.inArry = inArry;

        setTitle("Checkout");//sets the title of the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exits the program if the window is closed
        setSize(700, 700);//sets the size of the window
        setLocationRelativeTo(null);//sets the window to open in the middle of the screen

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));//sets the layout of the gui

        JLabel cardNumberLabel = new JLabel("Card Number (16 digits):");//sets the name of the input feild in the gui
        cardNumberField = new JTextField(20);//sets the feild 

        JLabel expirationLabel = new JLabel("Expiration (MM/YY):");//sets the name of the input feild in the gui
        expirationField = new JTextField(5);//sets the feild 

        JLabel securityCodeLabel = new JLabel("Security Code (3 or 4 digits):");//sets the name of the input feild in the gui
        securityCodeField = new JTextField(4);//sets the feild 

        JLabel zipCodeLabel = new JLabel("Zip Code (5 digits):");//sets the name of the input feild in the gui
        zipCodeField = new JTextField(5);//sets the feild 

        panel.add(cardNumberLabel);//adds the name of the feild
        panel.add(cardNumberField);//adds the input feild
        panel.add(expirationLabel);//adds the name of the feild
        panel.add(expirationField);//adds the input feild
        panel.add(securityCodeLabel);//adds the name of the feild
        panel.add(securityCodeField);//adds the input feild
        panel.add(zipCodeLabel);//adds the name of the feild
        panel.add(zipCodeField);//adds the input feild

        JButton submitButton = new JButton("Submit");//adds the submit button to the gui
        submitButton.addActionListener(new ActionListener() {//checks if the submit button has been pressed
            @Override
            public void actionPerformed(ActionEvent e) {//if pressed it will submit the reservation
                handleSubmit();
            }
        });

        add(panel, BorderLayout.CENTER);//sets the submit button in the middle
        add(submitButton, BorderLayout.SOUTH);//sets the submit button on the bottom

        setVisible(true);//makes the jframe visbale
    }

    private void handleSubmit() {
          String cardNumber = cardNumberField.getText();//sets cardNumber to the input 
        String expiration = expirationField.getText();//stes experation to the input    
        String securityCode = securityCodeField.getText();//sets security code to the input
        String zipCode = zipCodeField.getText();//sets zipCode to the input

        
        if (!Pattern.matches("\\d{16}", cardNumber)) {//checks if the creditcard input is valid
            JOptionPane.showMessageDialog(this, "Invalid card number format (should be 16 digits).");//if invalid displays a pop up window with this message
            return;
        }

        if (!Pattern.matches("\\d{2}/\\d{2}", expiration)) {//checks if the expiration input is valid
            JOptionPane.showMessageDialog(this, "Invalid expiration format (should be MM/YY).");//if invalid displays a pop up window with this message
            return;
        }

        if (!Pattern.matches("\\d{3,4}", securityCode)) {//checks if the security code input is valid
            JOptionPane.showMessageDialog(this, "Invalid security code format (should be 3 or 4 digits).");//if invalid displays a pop up window with this message
            return;
        }

        if (!Pattern.matches("\\d{5}", zipCode)) {//checks if the zipcode input is valid
            JOptionPane.showMessageDialog(this, "Invalid zip code format (should be 5 digits).");//if invalid displays a pop up window with this message
            return;
        }

       
        
        dispose();// closes the window if the data is valid
         Customer E = new Customer();//calls customer to create a reservation in the csv file
        E.CreateReservation(inArry.get(0), inArry.get(1), inArry.get(2), inArry.get(3), inArry.get(4), inArry.get(5));//inputs the array to the customer class function
       CSVReaderPrint L = new CSVReaderPrint();//calls the csv reader 
       String Hold = L.lastConNum();//gets a string with the confirmation number for the new reservation

       CSVReaderPrint F = new CSVReaderPrint();
       String Con = F.searchReservation(Hold);//searches the csv for the new reservation using the confirmation number

       Formating G = new Formating();
       String [] Frmtd = G.Frormat(Con);//takes the string in and reformats it into an array

       confirmationgui H = new confirmationgui();
       H.displayConfirmation(Frmtd);// takes in the array and displays the reservation confirmation
    }


}
