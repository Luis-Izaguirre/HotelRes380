
//this class was initially designed to combine both customer and employee Gui's together but then was later split into 2 seperate .jar files
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.SwingUtilities;

public class ClickableBoxesGUI extends JFrame {

    public ClickableBoxesGUI() {//gui with one button that opens the employee menue
        setTitle("Employee");//sets name for the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//ends program if the window is clossed
        setSize(300, 150);//sets the size of the window
        setLocationRelativeTo(null);//centers the window in the middle of the screen

        JPanel panel = new JPanel(new GridLayout(1, 1, 10, 10));//sets the layout of the gui

        JButton employeeButton = new JButton("Employee");//declares an button and names it Employee
        employeeButton.addActionListener(new ActionListener() {//checks if the button is clicked
            @Override
            public void actionPerformed(ActionEvent e) {//if clicked
                SwingUtilities.invokeLater(new Runnable() {//executes the method call asynchronously 
                    public void run() {
                        MenuGUI F = new MenuGUI();//calls the menuGUI class
                        F.Menugui();//starts the employee menu
                    }
                });
            }
        });


        panel.add(employeeButton);//adds the employee button to the gui
        add(panel);//adds everything to the jframe window
        setVisible(true); //sets the window to be visable
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ClickableBoxesGUI());
    }
}
