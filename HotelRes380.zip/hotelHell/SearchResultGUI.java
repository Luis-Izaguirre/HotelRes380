

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchResultGUI {
    public void displayConfirmation(String[] values) {//takes in an array
        
        JFrame frame = new JFrame("Reservation Found");//setting the title of the gui
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exits the program if closed
        frame.setSize(700, 700);//sets the size of the window
        frame.setLocationRelativeTo(null);//places the window in the center of the screen

    
        JPanel panel = new JPanel(new BorderLayout());//creates the wondow

        JTextArea textArea = new JTextArea(10, 30);//creates an area to display the text
        textArea.setEditable(false);// makes it so that the user cant edit the text

        for (String value : values) {// displays each value of the array on a new row
            textArea.append(value + "\n");
        }

        
        JScrollPane scrollPane = new JScrollPane(textArea);// in the event that the text is to long to display in the 700x700 panel it will let you scroll 
        panel.add(scrollPane, BorderLayout.CENTER);

        
        JButton closeButton = new JButton("Close");// creates a close button
        closeButton.addActionListener(new ActionListener() { //if the button is pressed 
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // closes the window
            }
        });
        panel.add(closeButton, BorderLayout.SOUTH);//adds the close button to the botom of the gui
        frame.getContentPane().add(panel);
        frame.setVisible(true);// makes the window visable
    }

  
}
