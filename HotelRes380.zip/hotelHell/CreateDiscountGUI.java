
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class CreateDiscountGUI extends JFrame {
    private JTextField confirmationNumberField;//sets a textfeild that will take in the confirmation number
    private JTextField discountAmountField;//sets a text feild that will take in the discount amount

    public void DiscountGUI() {
        setTitle("Create Discount");//title of the gui window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exits the program on closing of the window
        setSize(300, 200);//sets the hight of the window
        setLocationRelativeTo(null);//center the window in the middle of the screen

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));//setting up the layout of the gui

        JLabel confirmationNumberLabel = new JLabel("Confirmation Number (5 digits):");//labeling the text feild
        confirmationNumberField = new JTextField(10);//creating the text feild

        JLabel discountAmountLabel = new JLabel("Discount Amount:");//labeling the text feild
        discountAmountField = new JTextField(10);//seting the txt feild

        panel.add(confirmationNumberLabel);//adding the label to the gui
        panel.add(confirmationNumberField);//adding the textfeild to the gui
        panel.add(discountAmountLabel);//adding the label for the next text feild
        panel.add(discountAmountField);//adding the next text feild

        JButton createDiscountButton = new JButton("Create Discount");//creating the discount button
        createDiscountButton.addActionListener(new ActionListener() {//waiting for button to be presses
            @Override
            public void actionPerformed(ActionEvent e) {//if button is pressed
                String confirmationNumber = confirmationNumberField.getText();//setting the variable to the input
                String discountAmountText = discountAmountField.getText();//setting the variable to the input

                if (isValidConfirmationNumber(confirmationNumber) && isValidDiscountAmount(discountAmountText)) {//checks the inputs if they are valid
                    double discountAmount = Double.parseDouble(discountAmountText);//converts the discount string into a doubble
                    closeAndSetVariables(confirmationNumber, discountAmount);//passes the variables to the method and closes the window
                } else {
                    JOptionPane.showMessageDialog(CreateDiscountGUI.this, "Invalid input format.");//invalid inpput/s
                }
            }
        });

        panel.add(createDiscountButton);//adds the discount button to the gui

        add(panel);// adds the formatin to the pannel and displays the gui
        setVisible(true);//makes the gui visable
    }

    private boolean isValidConfirmationNumber(String confirmationNumber) {//checks that the confirmation number is 5 digits
        return confirmationNumber.matches("\\d{5}");
    }

    private boolean isValidDiscountAmount(String discountAmountText) {//checks that the discount input is valid
        try {
            double discountAmount = Double.parseDouble(discountAmountText);//converts the discount input to a double 
            return discountAmount >= 0; //checks the discount input is not negative
        } catch (NumberFormatException e) {//invalid input
            return false;
        }
    }

    private void closeAndSetVariables(String confirmationNumber, double discountAmount) {
        dispose();//closes the gui window
        String confirmedNumber = confirmationNumber;//sets the input variable
        double appliedDiscount = discountAmount;//sets the input variable
        CSVReaderPrint G = new CSVReaderPrint();//calls the CsvReaderPrint class
        try {
            G.Discount(confirmedNumber, appliedDiscount);//calls the discount method and iinputs the valid user inputs
        } catch (IOException e) {
            e.printStackTrace();//soomething went wrong
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CreateDiscountGUI());//main used for testing 
    }
}
