

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RoomSelectionGUI extends JDialog {

    private JComboBox<String> roomComboBox;//drop down list
    private JButton submitButton;//submitt button 
    private JTextArea displayArea;//allows the GUI to display text
    private String selectedRoom = "";//this variable will hold the user selection later

    public RoomSelectionGUI(Frame parent, String[] roomNumbers) {//take in an array of available rooms as an input
        super(parent, "Room Selection", true);//sets the title for the frame inputed by the function call
        setSize(700, 700);//window size
        setLayout(new BorderLayout());//sets the layout
        setLocationRelativeTo(null);//centers the window in the middle of the screen

        roomComboBox = new JComboBox<>(roomNumbers);//populates the dropdown with the available rooms from the input array
        submitButton = new JButton("Submit");//sets the name for the submitt button
        displayArea = new JTextArea();// sets up the text are that displays all the room info

        submitButton.setPreferredSize(new Dimension(80, 30));//size of the submit button

        submitButton.addActionListener(new ActionListener() {//checks if the button is used
            @Override
            public void actionPerformed(ActionEvent e) {// if the button is used 
                selectedRoom = (String) roomComboBox.getSelectedItem();//sets the user input to the room selected by the customer
                closeWindow();//closes the window
            }
        });

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        controlPanel.add(roomComboBox);//adds the drop down menu to the gui
        controlPanel.add(submitButton);//adds the submit button to the drop down menu

        add(controlPanel, BorderLayout.NORTH);//adds the dropdown menu and the button to the top of the gui
        add(new JScrollPane(displayArea), BorderLayout.CENTER);// sets the text with the room info to the center of the gui

        displayAllRoomsInfo(roomNumbers);// formats and displays the room info 

        setVisible(true);//makes the window visable
    }

    private void displayAllRoomsInfo(String[] roomNumbers) {//takes in the array with the available rooms
        String displayText = "Room List and Information:\n\n";

        for (String roomNumber : roomNumbers) {//itarates through each element of the array
            String roomType;
            double roomCost;

            if (roomNumber.startsWith("1")) {//sets the room type and cost based on the first number of the room number 
                roomType = "Single Bed Room";
                roomCost = 100;
            } else if (roomNumber.startsWith("2")) {//sets the room type and cost based on the first number of the room number 
                roomType = "Double Bed Room";
                roomCost = 150;
            } else if (roomNumber.startsWith("3")) {//sets the room type and cost based on the first number of the room number 
                roomType = "Suite";
                roomCost = 250;
            } else {//the room number is incorrect, check the rooms csv file and make sure the format is correct
                roomType = "Unknown Room Type";
                roomCost = 0;
            }

            displayText += "Room: " + roomNumber + "\n" + "Type: " + roomType + "\n" + "Cost: $" + roomCost + " per night\n\n";// formats the display text
        }

        displayArea.setText(displayText);//displays the room info
    }
    

    private void closeWindow() {//closes the window
        dispose();
    }

    public String getSelectedRoom() {//returns a string with the selected room
        return selectedRoom;
    }
}
