
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class DateRangeGenerator {
    public  ArrayList<String> PotentialDates(String inDate, String outDate) {//takes in 2 dates from the functions call
        String startDateStr = inDate;
        String endDateStr = outDate;
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy"); //date format
        
        try {
            Date startDate = dateFormat.parse(startDateStr);//formats the start date string to work with Date util
            Date endDate = dateFormat.parse(endDateStr); //formats the end date string to work with Date util
            
            ArrayList<String> dateArray = generateDateArray(startDate, endDate);// calls the generateDateArrat function
            
            return dateArray; //reports an array with all the dates between the start date and end date
        } catch (ParseException e) {
            e.printStackTrace();//something went wrong :(
            return null;
        }
        
    }
    
    public static ArrayList<String> generateDateArray(Date startDate, Date endDate) {
        ArrayList<String> dateArray = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();// calling calendar java util
        calendar.setTime(startDate); //setting the first date to be added to the Check in date
        
        while (!calendar.getTime().after(endDate)) {//while loop that checks that the date it is looking to add is not after the end date
            dateArray.add(new SimpleDateFormat("MM/dd/yyyy").format(calendar.getTime())); //adds current date to the array
            calendar.add(Calendar.DATE, 1);//inciments the date by one
        }

        return dateArray;//returns the array to the Lain Function
    }
}
