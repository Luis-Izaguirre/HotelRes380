

public class Customer{

    public void CreateReservation(String Name, String Contact, String guests, String CheckInDate, String CheckOutDate, String roomNum)
    {
      int Guests = Integer.parseInt(guests);
      int RoomNum = Integer.parseInt(roomNum);
        Double Fees= 0.00;// calculate the fees based on room type and number of nights of the stay
      //room type determines fees, room types will be determined before the method call
      int RoomType = 0; 
      if (RoomNum < 200) { //determines the room type based on the room number as well as determining the nightly fee
            Fees = 100.00;
            RoomType = 1;
          } else if(300 > RoomNum) {//determines the room type based on the room number as well as determining the nightly fee
            Fees = 150.00;
            RoomType = 2;
          } else if (RoomNum < 400) { //determines the room type based on the room number as well as determining the nightly fee
            Fees = 250.00;
            RoomType = 3;
          }
          Date F = new Date();
          Fees = Fees*(F.numberOfNights(CheckInDate, CheckOutDate));//calls method to calculate number of nights based on the dates and multiplies it by the fees per night to calculate the fees before any discounts

    
        CSVReaderPrint B = new CSVReaderPrint(); // adds reservation to the csv file
        B.AddReservation(Name,Contact,Guests,RoomNum,RoomType,CheckInDate,"2:00 PM",CheckOutDate,"11:00 AM",Fees,0.00,"No");//check in time, check out time, discounts, and checkin/out status are hard coded and some can be manipulated later
    }
}