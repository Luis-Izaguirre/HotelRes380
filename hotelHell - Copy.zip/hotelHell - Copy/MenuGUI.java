
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuGUI extends JFrame {
    public void Menugui() {
        setTitle("Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 700);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(2, 3, 10, 10));

        String[] buttonLabels = {
            "View All Reservations",
            "Check In",
            "Check Out",
            "Search Reservation",
            "Apply Discount",
            "Cancel Reservation" 
        };

        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String buttonName = ((JButton) e.getSource()).getText();
                    if (buttonName.equals("View All Reservations")) {
                        ArrayDisplayGUI arrayDisplayGUI = new ArrayDisplayGUI();
                        arrayDisplayGUI.ArrayDisplay();
                    } 
                    else if(buttonName.equals("Check In")){
                        CheckIn R = new CheckIn();
                        R.CheckInGuI();
                    }
                    else if(buttonName.equals("Check Out")){
                        CheckOut P = new CheckOut();
                        P.CheckOutGuI();
                    }else if (buttonName.equals("Cancel Reservation")) {
                       
                        CancelRes P = new CancelRes();
                        P.CancelGuI();
                    }else if (buttonName.equals("Search Reservation")) {
                        SearchGUI L = new SearchGUI();
                        L.serchGuI();
                    } else if (buttonName.equals("Apply Discount")) {
                        CreateDiscountGUI M = new CreateDiscountGUI();
                        M.DiscountGUI();
                    }else {
                        
                    }
                }
            });
            panel.add(button);
        }

        add(panel, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuGUI());
    }
}

