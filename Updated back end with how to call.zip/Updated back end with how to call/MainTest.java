import java.io.IOException;
import java.util.ArrayList;

public class MainTest {
    public static void main(String[] args) 
    {
        /*
        //How to call the customer Function, takes in name string, contact string, int numGuest(s), string check in date, string check out date,and int room number

        Customer S = new Customer();
        S.CreateReservation("Ori Cohen", "Ori@email.com", 5, "08/19/2023", "08/25/2023", 301);*/

        /*
       // How to call PrintReservations Function

        G = new CSVReaderPrint();
        String[][] reservationsArray = G.PrintReservations();
        for (String[] reservation : reservationsArray) {
            if (reservation != null) {
                System.out.println("Customer's Name: " + reservation[0] + ", Contact: " + reservation[1] + ", Guest(s): " + reservation[2] + ", Room Number: " + reservation[3] + ", Room Type: " + reservation[4] + ", Check In Date: " + reservation[5] + ", Check In Time: " + reservation[6] + ", Check Out Date: " + reservation[7] + ", Check Out Time: " + reservation[8] + ", Fees: " + reservation[9] + ", Discount: " + reservation[10] + ", Total: " + reservation[11] + ", Check in/out status: " + reservation[12] + ", Confirmation Number: " + reservation[13]);
            }
        }
      */
        /* 
        //How to call ReturnReservation this function searches for the reservation by the confirmation number and returns an array with the reservation details, takes in the reservation number as a string

        CSVReaderPrint G = new CSVReaderPrint();
        System.out.println(G.ReturnReservation("10001"));*/

        /*
       // How to check for room availability, put in the potential reservation check in and check out dates as strings in the format MM/DD/YYYY. An array with the available rooms will be returned
        
        
        DateRangeGenerator J = new DateRangeGenerator();
        ArrayList<String> S = J.PotentialDates("08/20/2023", "08/23/2023");
        CSVDateMatcher G = new CSVDateMatcher();
        G.UnoccupiedRooms(S);*/

        /*
       // How to call delete reservation function, takes in the reservation number as a string value.
        
        CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.DeleteRes("10001");
        } catch (IOException e) {
            e.printStackTrace();
        }*/

/*
//how to create a discount, takes in a reservation number string and a double with the discount amount.

CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.Discount("10001", 100.00);
        } catch (IOException e) {
            e.printStackTrace();
        }*/

/*
//how to change check in/out status, takes in reservation mumber string and a string with either "Checked In" or "Checked Out"

CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.CheckInOut("10001", "Checked In");
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
    
}
