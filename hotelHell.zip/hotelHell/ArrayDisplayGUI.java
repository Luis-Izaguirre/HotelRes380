
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class ArrayDisplayGUI extends JFrame {//uses jframe windows for the gui
    private JTextArea textArea;//seets up text box for the GUI

    public void ArrayDisplay() {
        CSVReaderPrint G = new CSVReaderPrint();//calls csvreaderprint class
        String[][] reservationsArray = G.PrintReservations();//gets a 2d array with all reservations 
        
        setTitle("All Reservations");//title for the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//ends program on closing of the window
        setSize(700, 700);//sets window/gui size
        setLocationRelativeTo(null);//sets the gui to open in the middle of the screen

        textArea = new JTextArea(10, 30);//sets the size of the viewable text box
        textArea.setEditable(false);//disables the user from edeting the text

        JScrollPane scrollPane = new JScrollPane(textArea);//uses JScrollPane to allow the user to scroll through all the reservations
        add(scrollPane, BorderLayout.CENTER);//sets the scrollpane to the center of the gui where the text will be

        StringBuilder sb = new StringBuilder();//declares a string builder that will be used to format the out put into easily readable text
        for (String[] row : reservationsArray) {//itterates through each element of the array
            if (row != null) { //checks that it has not reached the end of the array
                for (int i = 0; i < row.length; i++) {
                    if (i > 0) { // Skips the first index of the array due to it being the fist line of Reservations.csv which is used for formatting
                        sb.append(getPrefixForIndex(i));//adds the prefix for the value at index i and adds it to the string builder
                    }
                    sb.append(row[i]).append("\n");//moves to the next rrow after each value
                }
                sb.append("\n"); // adds a line between each reservation
            }
        }
        textArea.setText(sb.toString());//populates the text area with the reservation data

        JButton closeButton = new JButton("Close");//declares a close button
        closeButton.addActionListener(new ActionListener() {//waits for the button to be pressed
            @Override
            public void actionPerformed(ActionEvent e) {//if the close button is pressed
                dispose();//closes the window
            }
        });
        add(closeButton, BorderLayout.SOUTH);//adds the close button to the gui on the botom of the window

        setVisible(true);//makes the gui visable
    }

    private String getPrefixForIndex(int index) {//used to determine the prefixes for each array element
        //declares an array with the prefixes
        String[] prefixes = {
            "Customer's Name: ",
            "Contact: ",
            "Guest(s): ",
            "Room Number: ",
            "Room Type: ",
            "Check In Date: ",
            "Check In Time: ",
            "Check Out Date: ",
            "Check Out Time: ",
            "Fees: ",
            "Discount: ",
            "Total: ",
            "Check in/out status: ",
            "Confirmation Number: "
        };

        if (index >= 0 && index < prefixes.length) {//checks that the index is within the bounds of the array
            return prefixes[index];//returns the prefix for the value at index i of the array
        }
        return "";//reservation array may have an extra value error
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ArrayDisplayGUI arrayDisplayGUI = new ArrayDisplayGUI();
            arrayDisplayGUI.ArrayDisplay();
        });
    }
}
