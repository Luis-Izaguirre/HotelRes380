
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class ArrayDisplayGUI extends JFrame {
    private JTextArea textArea;

    public void ArrayDisplay() {
        CSVReaderPrint G = new CSVReaderPrint();
        String[][] reservationsArray = G.PrintReservations();
        
        setTitle("All Reservations");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 700);
        setLocationRelativeTo(null);

        textArea = new JTextArea(10, 30);
        textArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        StringBuilder sb = new StringBuilder();
        for (String[] row : reservationsArray) {
            if (row != null) { // Check for null row
                for (int i = 0; i < row.length; i++) {
                    if (i > 0) { // Skip adding the prefix for the first column
                        sb.append(getPrefixForIndex(i));
                    }
                    sb.append(row[i]).append("\n");
                }
                sb.append("\n"); // Add a line between arrays
            }
        }
        textArea.setText(sb.toString());

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(closeButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private String getPrefixForIndex(int index) {
        String[] prefixes = {
            "Customer's Name: ",
            "Contact: ",
            "Guest(s): ",
            "Room Number: ",
            "Room Type: ",
            "Check In Date: ",
            "Check In Time: ",
            "Check Out Date: ",
            "Check Out Time: ",
            "Fees: ",
            "Discount: ",
            "Total: ",
            "Check in/out status: ",
            "Confirmation Number: "
        };

        if (index >= 0 && index < prefixes.length) {
            return prefixes[index];
        }
        return "";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ArrayDisplayGUI arrayDisplayGUI = new ArrayDisplayGUI();
            arrayDisplayGUI.ArrayDisplay();
        });
    }
}
