

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchResultGUI {
    public void displayConfirmation(String[] values) {
        // Create the JFrame
        JFrame frame = new JFrame("Search Result");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setLocationRelativeTo(null);

        // Create a JPanel to hold the text area and close button
        JPanel panel = new JPanel(new BorderLayout());

        // Create a JTextArea to display the values
        JTextArea textArea = new JTextArea(10, 30);
        textArea.setEditable(false);

        // Append each value to the text area
        for (String value : values) {
            textArea.append(value + "\n");
        }

        // Add the text area to a scroll pane
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Add the scroll pane to the panel
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create and add a "Close" button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the window when the button is clicked
            }
        });
        panel.add(closeButton, BorderLayout.SOUTH);

        // Add the panel to the frame's content pane
        frame.getContentPane().add(panel);

        // Set the frame to be visible
        frame.setVisible(true);
    }

  
}
