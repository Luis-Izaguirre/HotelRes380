
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;

public class confirmationgui {
    public void displayConfirmation(String[] values) {
        // Create the JFrame
        JFrame frame = new JFrame("Display Confirmation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setLocationRelativeTo(null);

        // Create a JPanel to hold the text area
        JPanel panel = new JPanel(new BorderLayout());

        // Create a JTextArea to display the values
        JTextArea textArea = new JTextArea(10, 30);
        textArea.setEditable(false);

        // Append each value to the text area
        for (String value : values) {
            textArea.append(value + "\n");
        }

        // Add the text area to a scroll pane
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Add the scroll pane to the panel
        panel.add(scrollPane, BorderLayout.CENTER);

        // Add the panel to the frame's content pane
        frame.getContentPane().add(panel);

        // Set the frame to be visible
        frame.setVisible(true);
    }

   
}
