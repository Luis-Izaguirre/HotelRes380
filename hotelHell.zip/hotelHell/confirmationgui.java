
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;

public class confirmationgui {
    public void displayConfirmation(String[] values) {//takes in a string with the reservation details
        JFrame frame = new JFrame("Display Confirmation");//creates and titles the jframe
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//ends the program if the window is closed
        frame.setSize(700, 700);//sets the size of the window
        frame.setLocationRelativeTo(null);//ceters the window in the screen
        JPanel panel = new JPanel(new BorderLayout());//jpanel to hold the text
        JTextArea textArea = new JTextArea(10, 30);//displays the text data in the gui
        textArea.setEditable(false);//user cant edit any of the text

        for (String value : values) {//itterates through each element in the array
            textArea.append(value + "\n");//prints the elements and creats a new line
        }
        
        JScrollPane scrollPane = new JScrollPane(textArea);//lets the user scroll
        panel.add(scrollPane, BorderLayout.CENTER);//adds the scroll plane to the gui pannel
        frame.getContentPane().add(panel);//adds the pannel to the frame
        frame.setVisible(true);//makes the frame/window visable
    }

   
}
