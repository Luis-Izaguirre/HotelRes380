

import java.io.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class FileReaderPrint {

    public void prtFile(String userData) throws IOException {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("testing.txt", true));
            writer.write(userData);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getFileInfo(String fname) {
        try {
            BufferedReader read = new BufferedReader(new FileReader(fname));
            String tempStore = read.readLine();
            read.close();
            return tempStore;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}