public class Formating {
    public String[] Frormat(String Conf) {//takes in a string and converts it to an array
        String input = Conf;
        String[] values = input.split(", ");//splits the string using the commas and adds it to the array
        return values;//returns the array
    }
}
