
public class Formating {
    public String[] Frormat(String Conf) {
        String input = Conf;

        // Split the input string into individual values using comma as the delimiter
        String[] values = input.split(", ");

        return values;
    }
}
