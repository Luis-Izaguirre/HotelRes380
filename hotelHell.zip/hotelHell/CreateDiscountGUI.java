
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class CreateDiscountGUI extends JFrame {
    private JTextField confirmationNumberField;
    private JTextField discountAmountField;

    public void DiscountGUI() {
        setTitle("Create Discount");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));

        JLabel confirmationNumberLabel = new JLabel("Confirmation Number (5 digits):");
        confirmationNumberField = new JTextField(10);

        JLabel discountAmountLabel = new JLabel("Discount Amount:");
        discountAmountField = new JTextField(10);

        panel.add(confirmationNumberLabel);
        panel.add(confirmationNumberField);
        panel.add(discountAmountLabel);
        panel.add(discountAmountField);

        JButton createDiscountButton = new JButton("Create Discount");
        createDiscountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String confirmationNumber = confirmationNumberField.getText();
                String discountAmountText = discountAmountField.getText();

                if (isValidConfirmationNumber(confirmationNumber) && isValidDiscountAmount(discountAmountText)) {
                    // Convert the discount amount to a double
                    double discountAmount = Double.parseDouble(discountAmountText);

                    // Close the window and set the variables here
                    closeAndSetVariables(confirmationNumber, discountAmount);
                } else {
                    JOptionPane.showMessageDialog(CreateDiscountGUI.this, "Invalid input format.");
                }
            }
        });

        panel.add(createDiscountButton);

        add(panel);
        setVisible(true);
    }

    private boolean isValidConfirmationNumber(String confirmationNumber) {
        return confirmationNumber.matches("\\d{5}");
    }

    private boolean isValidDiscountAmount(String discountAmountText) {
        try {
            double discountAmount = Double.parseDouble(discountAmountText);
            return discountAmount >= 0; // Assuming discount amount should be non-negative
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void closeAndSetVariables(String confirmationNumber, double discountAmount) {
        // Close the window
        dispose();

        // Set the variables with the input values
        String confirmedNumber = confirmationNumber;
        double appliedDiscount = discountAmount;
        CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.Discount(confirmedNumber, appliedDiscount);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CreateDiscountGUI());
    }
}
