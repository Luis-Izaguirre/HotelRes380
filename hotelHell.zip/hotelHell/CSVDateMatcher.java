
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CSVDateMatcher {//This function checks for rooms that are unavailable during the dates inputed by the customer for their reservation 
    public ArrayList<String> UnoccupiedRooms(ArrayList<String> inputDates) {//takes in an array of dates
        ArrayList<String> matchedRoomNumbers = new ArrayList<>();//this array will be populated with room numbers for unavailable rooms

        try {
            
            BufferedReader csvReader = new BufferedReader(new FileReader("Rooms.csv"));//calling buffer reader and reading from Rooms.csv
            String row;

            while ((row = csvReader.readLine()) != null) { //  setting string row equal to the first or next line of the csv file untill the next row is empty
                
                String[] values = row.split(","); // takes string row and populates an array with the values of string row

                if (values.length >= 3) {

                    String roomNumber = values[0];  // takes the first index in the array which is the room number and assings it to a string
                    String dateList = values[2];  // takes the third index in the array and assings it to a string, this is a list of dates that the room is booked for and each date is seperated by a "-".
                    String[] bookedDates = dateList.split("-");// populating an array with all the dates in datelist and seperating them by the "-".
                         matchedRoomNumbers.add(roomNumber);
                    for (String inputDate : inputDates) { //  takes the input dates and searches each one against the booked dates array

                        for (String bookedDate : bookedDates) {  // cycles through the booked dates of one of the rooms

                            if (inputDate.equals(bookedDate)) { //   checks if one of the dates match

                            if (matchedRoomNumbers.contains(roomNumber)) { // checkes if the room number is alread in the array
                                matchedRoomNumbers.remove(roomNumber); //adds room number to the array
                                }
                                break;// restarts the while loop and the while loop will incrament to the next row until the next row is empty
                            }

                        
                        }

                    }


                }
            }

            csvReader.close(); //while loop is over and stops reading from the csv file

        } catch (IOException e) {

            e.printStackTrace();  // something broke, check input/ input format.:(
        }

        System.out.println("Matched Room Numbers: " + matchedRoomNumbers); //   for testing in terminal 
        return matchedRoomNumbers; // returns an  array with all of the available rooms
    }

}
