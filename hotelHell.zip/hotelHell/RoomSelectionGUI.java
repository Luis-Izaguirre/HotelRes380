

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RoomSelectionGUI extends JDialog {

    private JComboBox<String> roomComboBox;
    private JButton submitButton;
    private JTextArea displayArea;
    private String selectedRoom = "";

    public RoomSelectionGUI(Frame parent, String[] roomNumbers) {
        super(parent, "Room Selection GUI", true);
        setSize(700, 700);
        setLayout(new BorderLayout());

        roomComboBox = new JComboBox<>(roomNumbers);
        submitButton = new JButton("Submit");
        displayArea = new JTextArea();

        submitButton.setPreferredSize(new Dimension(80, 30));

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectedRoom = (String) roomComboBox.getSelectedItem();
                closeWindow();
            }
        });

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        controlPanel.add(roomComboBox);
        controlPanel.add(submitButton);

        add(controlPanel, BorderLayout.NORTH);
        add(new JScrollPane(displayArea), BorderLayout.CENTER);

        displayAllRoomsInfo(roomNumbers);

        setVisible(true);
    }

    private void displayAllRoomsInfo(String[] roomNumbers) {
        String displayText = "Room List and Information:\n\n";

        for (String roomNumber : roomNumbers) {
            String roomType;
            double roomCost;

            if (roomNumber.startsWith("1")) {
                roomType = "Single Bed Room";
                roomCost = 100;
            } else if (roomNumber.startsWith("2")) {
                roomType = "Double Bed Room";
                roomCost = 150;
            } else if (roomNumber.startsWith("3")) {
                roomType = "Suite";
                roomCost = 250;
            } else {
                roomType = "Unknown Room Type";
                roomCost = 0;
            }

            displayText += "Room: " + roomNumber + "\n" +
                           "Type: " + roomType + "\n" +
                           "Cost: $" + roomCost + " per night\n\n";
        }

        displayArea.setText(displayText);
    }
    

    private void closeWindow() {
        dispose();
    }

    public String getSelectedRoom() {
        return selectedRoom;
    }
}
