

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.ArrayList;

public class StringInputGUI extends JFrame {

    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JFormattedTextField textField4;
    private JFormattedTextField textField5;

    private JButton submitButton;

    private String variable1;
    private String variable2;
    private String variable3;
    private String variable4;
    private String variable5;
    ArrayList<String> inputArray = new ArrayList<>();

    public ArrayList<String> displayGUIAndWaitForSubmit() {
        setTitle("String Input GUI");
        setSize(700, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(7, 2));

        textField1 = new JTextField();
        textField2 = new JTextField();
        textField3 = new JTextField();
        textField4 = createFormattedTextField("##/##/####");
        textField5 = createFormattedTextField("##/##/####");

        submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                variable1 = textField1.getText();
                variable2 = textField2.getText();
                variable3 = textField3.getText();
                variable4 = textField4.getText();
                variable5 = textField5.getText();

                if (!isValidDate(variable4) || !isValidDate(variable5)) {
                    JOptionPane.showMessageDialog(null, "Enter the dates in MM/DD/YYYY format.", "Invalid Date Format", JOptionPane.ERROR_MESSAGE);
                    clearFields();
                } else {
                    inputArray.add(variable1);
                    inputArray.add(variable2);
                    inputArray.add(variable3);
                    inputArray.add(variable4);
                    inputArray.add(variable5);
                    dispose(); // Close the window
                }
            }
        });

        add(new JLabel("Name:"));
        add(textField1);
        add(new JLabel("Email:"));
        add(textField2);
        add(new JLabel("Guest Count:"));
        add(textField3);
        add(new JLabel("Check In Date (MM/DD/YYYY):"));
        add(textField4);
        add(new JLabel("Check Out Date (MM/DD/YYYY):"));
        add(textField5);
        add(submitButton);

        setVisible(true);

        // Wait until the user submits the data
        while (inputArray.isEmpty()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }

        return inputArray;
    }
    
    public JFormattedTextField createFormattedTextField(String format) {
        try {
            MaskFormatter maskFormatter = new MaskFormatter(format);
            maskFormatter.setPlaceholderCharacter('_');
            return new JFormattedTextField(maskFormatter);
        } catch (ParseException e) {
            e.printStackTrace();
            return new JFormattedTextField();
        }
    }

    public boolean isValidDate(String input) {
        String[] parts = input.split("/");
        if (parts.length != 3) {
            return false;
        }
        int month = Integer.parseInt(parts[0]);
        int day = Integer.parseInt(parts[1]);
        int year = Integer.parseInt(parts[2]);
        return (month >= 1 && month <= 12) && (day >= 1 && day <= 31) && (year >= 1000 && year <= 9999);
    }

    public void clearFields() {
        textField4.setValue(null);
        textField5.setValue(null);
    // ... (rest of your methods)
}
}
