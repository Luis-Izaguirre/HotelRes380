

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.ArrayList;

public class StringInputGUI extends JFrame {

    private JTextField textField1;//sets up the input for the name
    private JTextField textField2;//sets up the input for the email
    private JTextField textField3;//sets up the input for the guest count
    private JFormattedTextField textField4;// sets up the formated input for the check in date 
    private JFormattedTextField textField5;// sets up the formated input for the check out date 

    private JButton submitButton;//

    private String variable1;//initializes strings to be used to set the input data too for processing
    private String variable2;
    private String variable3;
    private String variable4;
    private String variable5;
    ArrayList<String> inputArray = new ArrayList<>();// this is the array that will be returned 

    public ArrayList<String> displayGUIAndWaitForSubmit() {
        setTitle("Reservation");//title of the gui
        setSize(700, 700);//size of the gui
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//end if the window is closed
        setLayout(new GridLayout(7, 2));//layout of the gui
        setLocationRelativeTo(null);//sets window to open in the middle of the screen

        textField1 = new JTextField();//creates a new input box
        textField2 = new JTextField();//creates a new input box
        textField3 = new JTextField();//creates a new input box
        textField4 = createFormattedTextField("##/##/####");//creates a new formated input box
        textField5 = createFormattedTextField("##/##/####");//creates a new formated input box

        submitButton = new JButton("Submit");//creates new submit button


        submitButton.addActionListener(new ActionListener() {//checks to see if submit has been clicked, if yes then it preforms the following operations
            @Override
            public void actionPerformed(ActionEvent e) {// submit button clicked
                variable1 = textField1.getText();//sets the variables equal to the inputs
                  variable2 = textField2.getText();
                variable3 = textField3.getText();
                variable4 = textField4.getText();
                variable5 = textField5.getText();

            if (!isValidDate(variable4) || !isValidDate(variable5)) {//checks to see if the date inputs are in the proper format
                    JOptionPane.showMessageDialog(null, "Enter the dates in MM/DD/YYYY format.", "Invalid Date Format", JOptionPane.ERROR_MESSAGE);// pop up windo if the dates are invalid
                    clearFields();// clears the date feilds
                } else {
                    inputArray.add(variable1);//ads the values to the input array
                    inputArray.add(variable2);
                    inputArray.add(variable3);
                    inputArray.add(variable4);
                    inputArray.add(variable5);
                    dispose(); // Close the window
                }
            }
        });

        add(new JLabel("Name:"));//adds the labels beside the input text boxes to the gui
        add(textField1);//adds the input text boxes to the gui
        add(new JLabel("Email:"));
        add(textField2);
        add(new JLabel("Guest Count:"));
        add(textField3);
        add(new JLabel("Check In Date (MM/DD/YYYY):"));
        add(textField4);
        add(new JLabel("Check Out Date (MM/DD/YYYY):"));
        add(textField5);
        add(submitButton);//adds the submit button to the gui

        setVisible(true);

        
        while (inputArray.isEmpty()) {//checks to see if the input array has any data in it
            try {
                Thread.sleep(100);// it waits if there is nothing in the array
            } catch (InterruptedException ex) {
                ex.printStackTrace();//error 
            }
        }

        return inputArray;// returns the input array
    }
    
    public JFormattedTextField createFormattedTextField(String format) {//creates a format for the date input boxes
        try {
            MaskFormatter maskFormatter = new MaskFormatter(format);
            maskFormatter.setPlaceholderCharacter('_');
            return new JFormattedTextField(maskFormatter);
        } catch (ParseException e) {//error
            e.printStackTrace();
            return new JFormattedTextField();
        }
    }

    public boolean isValidDate(String input) {//checks if the input dates for check in and check out are valid
        String[] parts = input.split("/");//creates an array based on the string input spliting it into 3 elements using the / to devide them up
        if (parts.length != 3) {//checks to see if it is long enough
            return false;
        }
        int month = Integer.parseInt(parts[0]);//sets the month to the first element of the array
        int day = Integer.parseInt(parts[1]);//sets the day to the seccond element
        int year = Integer.parseInt(parts[2]);//sets the year to the third element
        return (month >= 1 && month <= 12) && (day >= 1 && day <= 31) && (year >= 1000 && year <= 9999);//checks to see that each input is valid and there is no date line 13/32/0999
    }

    public void clearFields() {// clears the check in and check out date feilds 
        textField4.setValue(null);
        textField5.setValue(null);
    
}
}
