

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class SearchGUI extends JFrame {
    private JTextField inputField;//sets up the input

    public void serchGuI() {
        setTitle("Search Reservation");// window title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exit if the window is closed
        setSize(300, 150);//sets window size
        setLocationRelativeTo(null);//opens the window in the center of the screen

        JPanel panel = new JPanel();//creates the window
        JLabel label = new JLabel("Enter Confirmation Number:");//propts the user for an input
        inputField = new JTextField(10);//creates an input text box
        JButton checkInButton = new JButton("Search Reservation");//creates and names the button

        checkInButton.addActionListener(new ActionListener() {//waits for the search button to be pressed
            @Override
            public void actionPerformed(ActionEvent e) {//if the button has been pressed
                String input = inputField.getText();//sets the input to a variable
                if (isValidInput(input)) {//checkls that the input is in the right format
                    closeAndSetVariable(input);//closes the window and processes the input and calls the gui to display the data
                } else {
                    inputField.setText("");//clears the input box
                    JOptionPane.showMessageDialog(SearchGUI.this, "Invalid input. Please enter 5 numbers.");//displays pop up window saying the input is not valid
                }
            }
        });

        panel.add(label);//adds the label to the gui
        panel.add(inputField);// adds the input text box to the gui
        panel.add(checkInButton);// adds the search button to the gui

        add(panel);
        setVisible(true);//makes the window visable
    }

    private boolean isValidInput(String input) {
        return input.matches("\\d{5}");//makes sure that the input is in the corect format for the reservation number (5 digits)
    }

    private void closeAndSetVariable(String input) {
        dispose();// Closes the window

        String checkedInValue = input;//sets the variable too the input value
        CSVReaderPrint G = new CSVReaderPrint();
        String Con = G.searchReservation(checkedInValue);// gets a string with all the reservation details
        Formating P = new Formating();
       String [] Frmtd = P.Frormat(Con);// turns the string into an array

       SearchResultGUI H = new SearchResultGUI();//calls the search result gui to display the reservation details
       H.displayConfirmation(Frmtd);//inputs the array
    }

   
}