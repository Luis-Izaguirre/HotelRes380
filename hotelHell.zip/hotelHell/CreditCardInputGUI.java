
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class CreditCardInputGUI extends JFrame {
    private JTextField cardNumberField;
    private JTextField expirationField;
    private JTextField securityCodeField;
    private JTextField zipCodeField;
    private ArrayList<String> inArry;

    public void CreditCardInput(ArrayList<String> inArry) {
        this.inArry = inArry;

        setTitle("Credit Card Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 700);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));

        JLabel cardNumberLabel = new JLabel("Card Number (14 digits):");
        cardNumberField = new JTextField(20);

        JLabel expirationLabel = new JLabel("Expiration (MM/YY):");
        expirationField = new JTextField(5);

        JLabel securityCodeLabel = new JLabel("Security Code (3 or 4 digits):");
        securityCodeField = new JTextField(4);

        JLabel zipCodeLabel = new JLabel("Zip Code (5 digits):");
        zipCodeField = new JTextField(5);

        panel.add(cardNumberLabel);
        panel.add(cardNumberField);
        panel.add(expirationLabel);
        panel.add(expirationField);
        panel.add(securityCodeLabel);
        panel.add(securityCodeField);
        panel.add(zipCodeLabel);
        panel.add(zipCodeField);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleSubmit();
            }
        });

        add(panel, BorderLayout.CENTER);
        add(submitButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void handleSubmit() {
        String cardNumber = cardNumberField.getText();
        String expiration = expirationField.getText();
        String securityCode = securityCodeField.getText();
        String zipCode = zipCodeField.getText();

        // Validate input formats and lengths
        if (!Pattern.matches("\\d{14}", cardNumber)) {
            JOptionPane.showMessageDialog(this, "Invalid card number format (should be 14 digits).");
            return;
        }

        if (!Pattern.matches("\\d{2}/\\d{2}", expiration)) {
            JOptionPane.showMessageDialog(this, "Invalid expiration format (should be MM/YY).");
            return;
        }

        if (!Pattern.matches("\\d{3,4}", securityCode)) {
            JOptionPane.showMessageDialog(this, "Invalid security code format (should be 3 or 4 digits).");
            return;
        }

        if (!Pattern.matches("\\d{5}", zipCode)) {
            JOptionPane.showMessageDialog(this, "Invalid zip code format (should be 5 digits).");
            return;
        }

       
        // Data is valid, close the window
        dispose();
         Customer E = new Customer();
        E.CreateReservation(inArry.get(0), inArry.get(1), inArry.get(2), inArry.get(3), inArry.get(4), inArry.get(5));
       CSVReaderPrint L = new CSVReaderPrint();
       String Hold = L.lastConNum();

       CSVReaderPrint F = new CSVReaderPrint();
       String Con = F.searchReservation(Hold);
       System.out.println(Con);

       Formating G = new Formating();
       String [] Frmtd = G.Frormat(Con);

       confirmationgui H = new confirmationgui();
       H.displayConfirmation(Frmtd);
    }


}
