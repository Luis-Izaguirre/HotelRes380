
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuGUI extends JFrame {
    public void Menugui() {
        setTitle("Menu");//sets the title of the page
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//ends the program when the window is closed
        setSize(700, 700);//sets window size
        setLocationRelativeTo(null);//centers the window in the middle of the screen

        JPanel panel = new JPanel(new GridLayout(2, 3, 10, 10));//sets the window to have 2 rows of butons and 3 columns of buttons

        String[] buttonLabels = {//uses an array to store all of the button labels
            "View All Reservations","Check In","Check Out","Search Reservation","Apply Discount","Cancel Reservation" 
        };

        for (String label : buttonLabels) {//itarates through the array
            JButton button = new JButton(label);//creats a button for each element of the array
            button.addActionListener(new ActionListener() {//waits for a button to be pressed
                @Override
                public void actionPerformed(ActionEvent e) {//if a button is pressed it rus through the following
                    String buttonName = ((JButton) e.getSource()).getText();//sets the string equal to the name of the button that is pressed
                    if (buttonName.equals("View All Reservations")) {//if this button is pressed then it calls the gui for the view all reservations feature
                        ArrayDisplayGUI arrayDisplayGUI = new ArrayDisplayGUI();
                        arrayDisplayGUI.ArrayDisplay();
                    } 
                    else if(buttonName.equals("Check In")){//if this button is pressed then it calls the gui for the Check In feature
                        CheckIn R = new CheckIn();
                        R.CheckInGuI();
                    }
                    else if(buttonName.equals("Check Out")){//if this button is pressed then it calls the gui for the Check Out feature
                        CheckOut P = new CheckOut();
                        P.CheckOutGuI();
                    }else if (buttonName.equals("Cancel Reservation")) {//if this button is pressed then it calls the gui for the Cancel Reservation feature
                       
                        CancelRes P = new CancelRes();
                        P.CancelGuI();
                    }else if (buttonName.equals("Search Reservation")) {//if this button is pressed then it calls the gui for the Search Reservation feature
                        SearchGUI L = new SearchGUI();
                        L.serchGuI();
                    } else if (buttonName.equals("Apply Discount")) {//if this button is pressed then it calls the gui for the Apply Discount feature
                        CreateDiscountGUI M = new CreateDiscountGUI();
                        M.DiscountGUI();
                    }else {//does nothing if the code goes here something is wrong
                        
                    }
                }
            });
            panel.add(button);//adds the button to the gui in the order they apear in the array
        }

        add(panel, BorderLayout.CENTER);// sets the buttons to be in the center of the window

        setVisible(true);// makes the window viable
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuGUI());//runs the employee gui
    }
}

