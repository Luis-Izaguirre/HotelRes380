
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class CancelRes extends JFrame {
    private JTextField inputField;

    public void CancelGuI() {
        setTitle("Cancel Reservation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        JLabel label = new JLabel("Enter Confirmation Number:");
        inputField = new JTextField(10);
        JButton checkInButton = new JButton("Cancel Reservation");

        checkInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = inputField.getText();
                if (isValidInput(input)) {
                    // Close the window and set the variable here
                    closeAndSetVariable(input);
                } else {
                    // Clear the input field and show an error message
                    inputField.setText("");
                    JOptionPane.showMessageDialog(CancelRes.this, "Invalid input. Please enter 5 numbers.");
                }
            }
        });

        panel.add(label);
        panel.add(inputField);
        panel.add(checkInButton);

        add(panel);
        setVisible(true);
    }

    private boolean isValidInput(String input) {
        return input.matches("\\d{5}");
    }

    private void closeAndSetVariable(String input) {
        // Close the window
        dispose();

        // Set the variable with the input value
        String checkedInValue = input;
        CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.DeleteRes(checkedInValue);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CheckIn());
    }
}