


import java.awt.Frame;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.SwingUtilities;

public class hotel {
    public static void main(String[] args) 
    {
          StringInputGUI A = new StringInputGUI();
        ArrayList<String> inArry = A.displayGUIAndWaitForSubmit();
        for(int i = 0; i < inArry.size(); i++) {   
            System.out.print(inArry.get(i)+" ");
        } 

         DateRangeGenerator B = new DateRangeGenerator();
        ArrayList<String> S = B.PotentialDates(inArry.get(3), inArry.get(4));
        CSVDateMatcher C = new CSVDateMatcher();
        ArrayList<String> UsableRooms = C.UnoccupiedRooms(S);
        String[] URooms = UsableRooms.toArray(new String[UsableRooms.size()]);
        
        Frame parent = new Frame();
        RoomSelectionGUI dialog = new RoomSelectionGUI(parent, URooms);
        String selectedRoom = dialog.getSelectedRoom();
        System.out.println("Selected room: " + selectedRoom);
        inArry.add(selectedRoom);


        CreditCardInputGUI D = new CreditCardInputGUI();
        D.CreditCardInput(inArry);
        
       // CSVReaderPrint G = new CSVReaderPrint();
       // String[][] reservationsArray = G.PrintReservations();
       // ArrayDisplayGUI F = new ArrayDisplayGUI();
       //F.ArrayDisplay(reservationsArray);

       
        
      /*  SwingUtilities.invokeLater(() -> {
            ArrayDisplayGUI arrayDisplayGUI = new ArrayDisplayGUI();
            arrayDisplayGUI.ArrayDisplay();
        });*/




        //FileReaderPrint S = new FileReaderPrint();
        //System.out.println(S.getFileInfo("testing.txt"));
       
        /*
        //How to call the customer Function, takes in name string, contact string, int numGuest(s), string check in date, string check out date,and int room number

        Customer S = new Customer();
        S.CreateReservation("Ori Cohen", "Ori@email.com", 5, "08/19/2023", "08/25/2023", 301);*/

        /*
       // How to call PrintReservations Function

        CSVReaderPrint G = new CSVReaderPrint();
        String[][] reservationsArray = G.PrintReservations();
        for (String[] reservation : reservationsArray) {
            if (reservation != null) {
                System.out.println("Customer's Name: " + reservation[0] + ", Contact: " + reservation[1] + ", Guest(s): " + reservation[2] + ", Room Number: " + reservation[3] + ", Room Type: " + reservation[4] + ", Check In Date: " + reservation[5] + ", Check In Time: " + reservation[6] + ", Check Out Date: " + reservation[7] + ", Check Out Time: " + reservation[8] + ", Fees: " + reservation[9] + ", Discount: " + reservation[10] + ", Total: " + reservation[11] + ", Check in/out status: " + reservation[12] + ", Confirmation Number: " + reservation[13]);
            }
        }
      */
        /* 
        //How to call ReturnReservation this function searches for the reservation by the confirmation number and returns an array with the reservation details, takes in the reservation number as a string

        CSVReaderPrint G = new CSVReaderPrint();
        System.out.println(G.ReturnReservation("10001"));*/

        /*
       // How to check for room availability, put in the potential reservation check in and check out dates as strings in the format MM/DD/YYYY. An array with the available rooms will be returned
        
        
        DateRangeGenerator J = new DateRangeGenerator();
        ArrayList<String> S = J.PotentialDates("08/20/2023", "08/23/2023");
        CSVDateMatcher G = new CSVDateMatcher();
        G.UnoccupiedRooms(S);*/

        /*
       // How to call delete reservation function, takes in the reservation number as a string value.
        
        CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.DeleteRes("10001");
        } catch (IOException e) {
            e.printStackTrace();
        }*/

/*
//how to create a discount, takes in a reservation number string and a double with the discount amount.

CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.Discount("10001", 100.00);
        } catch (IOException e) {
            e.printStackTrace();
        }*/

/*
//how to change check in/out status, takes in reservation mumber string and a string with either "Checked In" or "Checked Out"

CSVReaderPrint G = new CSVReaderPrint();
        try {
            G.CheckInOut("10001", "Checked In");
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
    
}
